"""
Given a comma separated input file with 18 columns, e.g.,

```
Date received,Product,Sub-product,Issue,Sub-issue,Consumer complaint narrative,Company public response,Company,State,ZIP code,Tags,Consumer consent provided?,Submitted via,Date sent to company,Company response to consumer,Timely response?,Consumer disputed?,Complaint ID
2019-09-24,Debt collection,I do not know,Attempts to collect debt not owed,Debt is not yours,"transworld systems inc. is trying to collect a debt that is not mine, not owed and is inaccurate.",,TRANSWORLD SYSTEMS INC,FL,335XX,,Consent provided,Web,2019-09-24,Closed with explanation,Yes,N/A,3384392
2019-09-19,"Credit reporting, credit repair services, or other personal consumer reports",Credit reporting,Incorrect information on your report,Information belongs to someone else,,Company has responded to the consumer and the CFPB and chooses not to provide a public response,Experian Information Solutions Inc.,PA,15206,,Consent not provided,Web,2019-09-20,Closed with non-monetary relief,Yes,N/A,3379500
2020-01-06,"Credit reporting, credit repair services, or other personal consumer reports",Credit reporting,Incorrect information on your report,Information belongs to someone else,,,Experian Information Solutions Inc.,CA,92532,,N/A,Email,2020-01-06,In progress,Yes,N/A,3486776
2019-10-24,"Credit reporting, credit repair services, or other personal consumer reports",Credit reporting,Incorrect information on your report,Information belongs to someone else,,Company has responded to the consumer and the CFPB and chooses not to provide a public response,"TRANSUNION INTERMEDIATE HOLDINGS, INC.",CA,925XX,,Other,Web,2019-10-24,Closed with explanation,Yes,N/A,3416481
2019-11-20,"Credit reporting, credit repair services, or other personal consumer reports",Credit reporting,Incorrect information on your report,Account information incorrect,I would like the credit bureau to correct my XXXX XXXX XXXX XXXX balance. My correct balance is XXXX,Company has responded to the consumer and the CFPB and chooses not to provide a public response,"TRANSUNION INTERMEDIATE HOLDINGS, INC.",TX,77004,,Consent provided,Web,2019-11-20,Closed with explanation,Yes,N/A,3444592
```
the script generates a list of all unique pairs of product and year (of Date received), the total number of complaints received for that product and year, the total number of companies receiving at least one complaint for that product and year, and the highest percentage of total complaints filed against one company for that product and year, which is listed in alphabetical order based on product and ascending order based on year. E.g.,
```
"credit reporting, credit repair services, or other personal consumer reports",2019,3,2,67
"credit reporting, credit repair services, or other personal consumer reports",2020,1,1,100
debt collection,2019,1,1,100
```

"""

import sys, collections
 
input_filename, output_filename = sys.argv[1:]

# Keep track of counter for each pair of product and year
pairs = collections.defaultdict(collections.Counter)

# Track number of lines read
n_lines = 0
print('\nProcessing the input file:', input_filename, '\n')
with open(input_filename, 'r') as input_file:

    complaint = input_file.readline()
    complaint = input_file.readline()

    while len(complaint) > 0:
    	# Tranform to lowercase
    	complaint = complaint.lower()
    	n_lines += 1

    	# Print progress every million lines
    	if n_lines % 10 ** 6 == 0:
    		print('Number of lines processed:', n_lines // 10 ** 6, 'million')

    	# Strip commas inside quoted text
    	if complaint.find('"') >= 0:

    		start = complaint.find('"')
    		end = -1
    		# Strip all commas inside all the quotations
    		while start >= 0:
    			start += end + 1
    			end = complaint[start + 1:].find('"')
    			if end >= 0:
    				end += start + 1
    			complaint = complaint[:start] + complaint[start:end + 1].replace(',', '|') + complaint[end + 1:]
    			start = complaint[end + 1:].find('"')

    	complaint = complaint.split(',')

    	# Make sure that each row has 18 columns
    	if len(complaint) != 18:
    		print('FAIL: A row must have 18 columns but found this row')
    		print(','.join(complaint))
    		sys.exit(0)

    	# Product name
    	product = complaint[1].replace('|', ',')

    	# Access the key
    	pairs[(product, complaint[0].strip()[:4])][complaint[7].replace('|', ',')] += 1

    	complaint = input_file.readline()

print('Total number of lines processed:', "{:,}".format(n_lines))

# Write the output file
with open(output_filename, 'w') as output_file:
	# Sort the keys product (alphabetically) and year (ascending)
	for (product, year), counter in sorted(pairs.items(), key = lambda pair: (pair[0][0], int(pair[0][1]))):
		# Write to the output file in ascending order
		total_complaints = sum(counter.values())
		total_companies = len(counter)
		_, highest_counts = counter.most_common(1)[0]
		highest_percentage = int(highest_counts / total_complaints * 100 + 0.5)
		next_line = ','.join([product, year, str(total_complaints), str(total_companies), str(highest_percentage)])
		next_line += '\n'
		output_file.write(next_line)