这是cs231n的第一次作业，下面是步骤

1. 获取数据

在该目录下

```bash
sudo apt-get install wget;
cd cs231n/datasets/;
bash get_datasets.sh
```

可以得到下面的效果

<img src='https://ws3.sinaimg.cn/large/006tNbRwly1fvbq7y6bm4j30zw0a4gmv.jpg' width='700'>

2. 打开jupyter notebook

```bash
jupyter notebook
```

3. 完成 `knn.ipynb` 和 `cs231n/classifier/k_nearest_neighbor.py` 中的 `TODO`

4. 完成 
